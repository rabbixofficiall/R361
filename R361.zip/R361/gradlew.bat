@echo off
gradlew %*